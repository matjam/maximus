/*
 * $Id: enc_gwy.h,v 1.1.1.1 2002/03/28 00:02:24 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * Prototypes of the functions located in ENC_GWY.C are declared here.
 *
 */

#ifndef ENC_GWY_INCLUDED
#define ENC_GWY_INCLUDED

/* Prototypes */

void encode_stub(int method);
void encode_f_stub();

#endif

