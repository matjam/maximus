/*
 * $Id: integr.c,v 1.1.1.1 2002/03/28 00:03:01 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * This is a portable version of the integrity validation record.
 *
 */

static char intergrity_identifier[]={0xB0, 0x03, 0xB0, 0x02, 0xB0, 0x03,
                                     0xB0, 0x04, 0xB0, 0x05,
                                     0x90, 0x90, 0x90, 0x90,
                                     0x90, 0x90, 0x90, 0x90,
                                     0xB0, 0x01, 0xB0, 0x01, 0xC3
                                    };
