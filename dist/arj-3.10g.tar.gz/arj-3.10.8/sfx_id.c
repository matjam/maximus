/*
 * $Id: sfx_id.c,v 1.1.1.2 2002/03/28 00:03:24 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * This is a portable version of the SFX identifier.
 *
 */

static char sfx_id[]="zyxwbaaRJsfXaRJsfX";
